![Image of Info](https://github.com/TheAppWizard/TheAppWizard/blob/main/info.png)

<table>
  <tr>
    <td valign="top"><img src="https://github-readme-stats.vercel.app/api?username=theappwizard&show_icons=true&title_color=ffffff&icon_color=34abeb&text_color=ffffff&bg_color=000000"/></td>
  </tr>
</table>


    
