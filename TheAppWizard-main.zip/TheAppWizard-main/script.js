    // typing text animation script
    var typed = new Typed(".typing", {
        strings: ["Engineer","Developer", "Blogger", "Designer", "Freelancer","TheAppWizard"],
        typeSpeed: 100,
        backSpeed: 60,
        cursorChar: ' |',
        smartBackspace: true,
        loop: true
    });
